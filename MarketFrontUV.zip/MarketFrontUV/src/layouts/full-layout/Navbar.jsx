import navbar from '../../components/Navbar/Navbar';
import Box from '@mui/material/Box';

export default function ButtonAppBar() {
    return (
      <Box>
        <navbar />
      </Box>
    );
  }
  
import React from 'react'
import Options from './Components/Options'
import { Box } from '@mui/system'

const CartasyPosts = () => {
  return (    
      <Box>
        < Options/> 
      </Box>
  )
}

export default CartasyPosts
import React from 'react'
import SingInAside from './Components/Register_component'
import { Box } from '@mui/system'

const Register = () => {
  return (
      <Box>
        <SingInAside /> 
      </Box>
  )
}

export default Register
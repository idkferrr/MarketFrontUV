import React from 'react'
import LogIn from './Components/Login_component'
import { Box } from '@mui/system'

const Login = () => {
  return (    
      <Box>
        < LogIn/> 
      </Box>
  )
}

export default Login